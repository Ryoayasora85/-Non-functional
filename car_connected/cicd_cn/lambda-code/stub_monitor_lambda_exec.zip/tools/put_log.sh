#!/bin/bash
 
# リージョン
export AWS_DEFAULT_REGION=ap-northeast-1
 
# CloudWatchLogs設定
#LogGroupName="/ecs/logs/inv-aws-scenario-monitoring"
LogGroupName="/monitoring-lambda-dummy"
#LogStreamName="inv-aws-scenario-monitoring/inv-aws-scenario-monitoring-container/8cb3bdf6-592d-431c-be41-7e1ed586ef5b"
#LogStreamName="monitoring-lambda-dummy/inv-aws-program-monitoring/2019-07-11-15-20"
LogStreamName="test20190716"
 
# CloudWatchLogsにPUTするメッセージ
#Mess=$1
Mess="LogLevel:ERROR Uuid:7a33d6d6-878f-4f1d-bc80-f1e09dbcc4cc Time:2019/04/10 13:33:51.299+09:00 Env:DEV Service:wfi Pgm:jp.ne.internavi.cloud.wifi.common.handler.GlobalExceptionHandler.restClientExceptionHandler(GlobalExceptionHandler.java:172) RecId:777777777 Message:wfi log X-AppVer:0.0.7 X-ErrorId:ER001 X-IccId: X-ExceptionMsg:I/O error on POST request for "/localhost/api/get_iccid": null; nested exception is org.apache.http.client.ClientProtocolException X-Exception:org.springframework.web.client.ResourceAccessException X-DetailedValue:An external error occurred. (outside 404 not found\, required error\, validation error) X-DetailedMsg:org.springframework.web.client.ResourceAccessException: I/O error on POST request for "/localhost/api/get_iccid": null; nested exception is org.apache.http.client.ClientProtocolException"
#Mess="Uuid:7a33d6d6-878f-4f1d-bc80-f1e09dbcc4cc Time:2019/04/10 13:33:51.299+09:00 Env:DEV Service:wfi Pgm:jp.ne.internavi.cloud.wifi.common.handler.GlobalExceptionHandler.restClientExceptionHandler(GlobalExceptionHandler.java:172) RecId:777777777 Message:wfi log X-AppVer:0.0.7 X-ErrorId:ER001 X-IccId: X-ExceptionMsg:I/O error on POST request for "/localhost/api/get_iccid": null; nested exception is org.apache.http.client.ClientProtocolException X-Exception:org.springframework.web.client.ResourceAccessException X-DetailedValue:An external error occurred. (outside 404 not found\, required error\, validation error) X-DetailedMsg:org.springframework.web.client.ResourceAccessException: I/O error on POST request for "/localhost/api/get_iccid": null; nested exception is org.apache.http.client.ClientProtocolException"
 
# コーテーションを取り除く
Mess=`echo $Mess | sed -e "s/'//g"`
 
# put-log-eventに利用するトークン
UploadSequenceToken=$(aws logs describe-log-streams --log-group-name "$LogGroupName" --query 'logStreams[?logStreamName==`'$LogStreamName'`].[uploadSequenceToken]' --output text)
 
# put-log-eventに利用するタイムスタンプ
TimeStamp=`date "+%s%N" --utc`
TimeStamp=`expr $TimeStamp / 1000000`
 
# put-log-eventsの実行
if [ "$UploadSequenceToken" != "None" ]
then
  # トークン有りの場合
  aws logs put-log-events --log-group-name "$LogGroupName" --log-stream-name "$LogStreamName" --log-events timestamp=$TimeStamp,message="$Mess" --sequence-token $UploadSequenceToken
else
  # トークン無しの場合（初回のput）
  aws logs put-log-events --log-group-name "$LogGroupName" --log-stream-name "$LogStreamName" --log-events timestamp=$TimeStamp,message="$Mess"
fi
