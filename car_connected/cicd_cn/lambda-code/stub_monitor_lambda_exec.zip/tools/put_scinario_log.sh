#!/bin/bash
 
# リージョン
export AWS_DEFAULT_REGION=ap-northeast-1
 
# CloudWatchLogs設定
LogGroupName="/ecs/logs/inv-aws-scenario-monitoring"
#LogGroupName="/monitoring-lambda-dummy"
LogStreamName="jmeter/scenario01/dde30334-c3a3-40d4-a0df-5a695f2dca23"
#LogStreamName="monitoring-lambda-dummy/inv-aws-program-monitoring/2019-06-19-02-12"
 
# CloudWatchLogsにPUTするメッセージ
Mess=$1
 
# コーテーションを取り除く
Mess=`echo $Mess | sed -e "s/'//g"`
 
# put-log-eventに利用するトークン
UploadSequenceToken=$(aws logs describe-log-streams --log-group-name "$LogGroupName" --query 'logStreams[?logStreamName==`'$LogStreamName'`].[uploadSequenceToken]' --output text)
 
# put-log-eventに利用するタイムスタンプ
TimeStamp=`date "+%s%N" --utc`
TimeStamp=`expr $TimeStamp / 1000000`
 
# put-log-eventsの実行
if [ "$UploadSequenceToken" != "None" ]
then
  # トークン有りの場合
  aws logs put-log-events --log-group-name "$LogGroupName" --log-stream-name "$LogStreamName" --log-events timestamp=$TimeStamp,message="$Mess" --sequence-token $UploadSequenceToken
else
  # トークン無しの場合（初回のput）
  aws logs put-log-events --log-group-name "$LogGroupName" --log-stream-name "$LogStreamName" --log-events timestamp=$TimeStamp,message="$Mess"
fi
